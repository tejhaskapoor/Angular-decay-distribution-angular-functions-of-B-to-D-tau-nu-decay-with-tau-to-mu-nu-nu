 J functions of   B->D^* tau nu (tau to mu nu nu) 

This mathematica notebook is a part of appendix of PhD thesis of Tejhas Kapoor
IJC Lab
University Paris-Saclay 


This mathematica file contains the J functions used for writing the angular decay distribution of B to D* tau nu, where the tau decays to mu nu nu. The theoretical details of this calculation and the definition of J functions is given in my PhD thesis, of which this file is a part. 

One needs Mathematica on their device to open this notebook. 